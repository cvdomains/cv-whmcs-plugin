<?php

# Configuration array
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

require_once __DIR__ . '/autoload.php';

use WHMCS\Carbon;
use WHMCS\Database\Capsule;
use WHMCS\Domain\Registrar\Domain;

use WHMCS\Module\Registrar\OlaCV\Net\EPP\Client;

use WHMCS\Domains\DomainLookup\SearchResult;
use WHMCS\Domains\DomainLookup\ResultsList;

const STATUS_INACTIVE = "inactive";
const STATUS_SERVER_HOLD = "serverHold";
const STATUS_PENDING_CREATE = "pendingCreate";
const STATUS_PENDING_DELETE = "pendingDelete";
const STATUS_EXPIRED = "expired";

const STATUS_LOCKED = 'locked';
const STATUS_UNLOCKED = 'unlocked';

function olacv_MetaData(): array
{
  return [
    'DisplayName' => 'OlaCV Registrar Module',
    'APIVersion' => '1.0',
  ];
}

function olacv_getConfigArray(): array
{
  return [
    "Username" => ["Type" => "text", "Size" => "20", "Description" => "Enter your EPP username here"],
    "Password" => ["Type" => "password", "Size" => "20", "Description" => "Enter your EPP password here"],
    "Server" => ["Type" => "text", "Size" => "20", "Description" => "Enter EPP Server Address"],
    "Port" => ["Type" => "text", "Size" => "20", "Description" => "Enter EPP Server Port"],
    "SSL" => ["Type" => "yesno", 'Description' => "Tick to enable"],
    "Certificate" => ["Type" => "text", "Description" => "(Optional) Path of certificate .pem"],
  ];
}

function olacv_AdminCustomButtonArray()
{
  return [
    "Approve Transfer" => "ApproveTransfer",
    "Cancel Transfer Request" => "CancelTransferRequest",
    "Reject Transfer" => "RejectTransfer",
    "Update Additional fields" => "UpdateFieldsAdditional",
  ];
}

function olacv_ClientAreaCustomButtonArray()
{
  return [
//    "Lock Domain" => "LockDomain",
//    "Unlock Domain" => "UnlockDomain",
//    "Manage DNSSEC Records" => 'manageDNSSECRecords' //DNSSEC Button
  ];
}

function olacv_CheckAvailability($params)
{
  $searchTerm = trim((string)($params['searchTerm'] ?? $params['sld']));
  $premiumEnabled = (bool)($params['premiumEnabled'] ?? false);
  $tldsToInclude = (array)($params['tldsToInclude'] ?? []);

  $punyCodeSearchTerm = trim((string)($params['punyCodeSearchTerm'] ?? ''));
  $isIdnDomain = (bool)($params['isIdnDomain'] ?? false);

  $domainEntries = '';
  foreach ($tldsToInclude as $tld) {
    $domainEntries .= '<domain:name>' . $searchTerm .$tld . '</domain:name>';
  }

  try {
    $client = _olacv_Client();

    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
  <command>
    <check>
      <domain:check xmlns:domain="urn:ietf:params:xml:ns:domain-1.0">' . $domainEntries . '</domain:check>
    </check>
    <extension>
      <fee:check xmlns:fee="urn:ietf:params:xml:ns:epp:fee-1.0">
        <fee:currency>USD</fee:currency>
        <fee:command name="create"><fee:period unit="y">1</fee:period></fee:command>
        <fee:command name="renew"><fee:period unit="y">1</fee:period></fee:command>
        <fee:command name="transfer"><fee:period unit="y">1</fee:period></fee:command>
        <fee:command name="restore"><fee:period unit="y">1</fee:period></fee:command>
      </fee:check>
    </extension>
    <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
  </command>
</epp>';
    $response = $client->request($xml);
    logModuleCall('olacv', 'availability', $xml, $response, null, []);

    _olacv_logout($client);

    return _olacv_parseDomainCheckResponse($response, $premiumEnabled);
  } catch (\Exception $e) {
    return [
      'error' => $e->getMessage(),
    ];
  }
}

function olacv_GetDomainSuggestions($params)
{
  $searchTerm = $params['searchTerm'];
  $tldsToInclude = (array)($params['tldsToInclude'] ?? []);
  $premiumEnabled = (bool)($params['premiumEnabled'] ?? false);

  $isIdnDomain = (bool)($params['isIdnDomain'] ?? false);
  $punyCodeSearchTerm = $params['punyCodeSearchTerm'];
  $suggestionSettings = $params['suggestionSettings'];

  $list = _olacv_generateSuggestions($searchTerm);
  $domains = '';
  foreach ($list as $entry) {
    $domains .= '<domain:name>' . $entry . '</domain:name>';
  }

  try {
    $client = _olacv_Client();

    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
  <command>
    <check>
      <domain:check xmlns:domain="urn:ietf:params:xml:ns:domain-1.0">' . $domains . '</domain:check>
    </check>
    <extension>
      <fee:check xmlns:fee="urn:ietf:params:xml:ns:epp:fee-1.0">
        <fee:currency>USD</fee:currency>
        <fee:command name="create"><fee:period unit="y">1</fee:period></fee:command>
        <fee:command name="renew"><fee:period unit="y">1</fee:period></fee:command>
        <fee:command name="transfer"><fee:period unit="y">1</fee:period></fee:command>
        <fee:command name="restore"><fee:period unit="y">1</fee:period></fee:command>
      </fee:check>
    </extension>
    <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
  </command>
</epp>';

    $response = $client->request($xml);
    logModuleCall('olacv', 'suggestions', $xml, $response, null, []);

    _olacv_logout($client);

    return _olacv_parseDomainCheckResponse($response, $premiumEnabled);
  } catch (Exception $e) {
    return [
      'error' => $e->getMessage(),
    ];
  }
}

function olacv_GetDomainInformation($params)
{
  $sld = $params["sld"];
  $tld = $params["tld"];
  $domain = "$sld.$tld";

  try {
    $client = _olacv_Client();
    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
            <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
                <command>
                    <info>
                        <domain:info xmlns:domain="urn:ietf:params:xml:ns:domain-1.0">
                            <domain:name hosts="all">' . $domain . '</domain:name>
                        </domain:info>
                    </info>
                    <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
                </command>
            </epp>';

    $request = $client->request($xml);
    logModuleCall('olacv', 'GetDomainInformation', $xml, $request, null, []);

    $dom = new EppParser($request);
    $response = $dom->getDomainData();

    $registrantDetails = _olacv_getContactDetail($client, $response['registrant']);

    _olacv_logout($client);
    
    var_dump($response);
    
    return (new Domain)
        ->setDomain($response['domain'])
        ->setNameservers($response['nameservers'])
        ->setRegistrationStatus($response['status'])
        ->setTransferLock($response['transferlock'])
        ->setTransferLockExpiryDate(null)
        ->setExpiryDate(Carbon::createFromFormat('Y-m-d', substr($response['dates']['expiry'], 0, 10)))
    //        ->setRestorable($response['restorable'])
    //        ->setIdProtectionStatus($response['addons']['hasidprotect'])
    //        ->setDnsManagementStatus($response['addons']['hasdnsmanagement'])
    //        ->setEmailForwardingStatus($response['addons']['hasemailforwarding'])
    //        ->setIsIrtpEnabled(in_array($response['tld'], ['.com']))
    //        ->setIrtpOptOutStatus($response['irtp']['optoutstatus'])
    //        ->setIrtpTransferLock($response['irtp']['lockstatus'])
    //        ->IrtpTransferLockExpiryDate($irtpTransferLockExpiryDate)
    //        ->setDomainContactChangePending($response['status']['contactpending'])
    //        ->setPendingSuspension($response['status']['pendingsuspend'])
    //        ->setDomainContactChangeExpiryDate($response['status']['expires'])
        ->setRegistrantEmailAddress($registrantDetails['Email'])
        ->setIrtpVerificationTriggerFields(
            [
                'Registrant' => [
                    $registrantDetails['Contact Name'],
                    'Last Name',
                    $registrantDetails['Company'],
                    $registrantDetails['Email'],
                ],
            ]
    );
  } catch (Exception $e) {
    $values["error"] = $e->getMessage();
  }

  return $values;
}

function olacv_RequestDelete($params)
{
  $sld = $params['sld'];
  $tld = $params['tld'];

  $domain = "$sld.$tld";

  try {
    $client = _olacv_Client();

    # Request Delete
    $request = $client->request(
      $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
    <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
        <command>
            <delete>
                <domain:delete xmlns:domain="urn:ietf:params:xml:ns:domain-1.0">
                    <domain:name>' . $domain . '</domain:name>
                </domain:delete>
            </delete>
            <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
        </command>
    </epp>
'
    );
    logModuleCall('olacv', 'RequestDelete', $xml, $request, null, []);

    $doc = new EppParser($request);

    _olacv_logout($client);
    $msg = $doc->getMsg();

    # Check result
    if (!$doc->isSuccess()) {
      $values['error'] = 'RequestDelete/domain-info(' . $domain . '): Code(' . $doc->getCode() . ") {$msg}";
      return $values;
    }

    $values['status'] = $msg;
  } catch (Exception $e) {
    $values["error"] = 'RequestDelete/EPP: ' . $e->getMessage();
    return $values;
  }

  return $values;
}

# Function to return current nameservers
function olacv_GetNameservers($params): array
{
  # Grab variables
  $sld = $params["sld"];
  $tld = $params["tld"];

  $domain = "$sld.$tld";

  try {
    $client = _olacv_Client();

    $authCode = _olacv_generateAuthCode($domain);
    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
   <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
     <command>
       <info>
         <domain:info xmlns:domain="urn:ietf:params:xml:ns:domain-1.0">
            <domain:name hosts="all">' . $domain . '</domain:name>
            <domain:authInfo>
                <domain:pw>' . $authCode . '</domain:pw>
            </domain:authInfo>
         </domain:info>
       </info>
       <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
     </command>
   </epp>';
    $result = $client->request($xml);
    logModuleCall('olacv', 'GetNameservers', $xml, $result, null, [$authCode]);

    $doc = new EppParser($result);

    if (!$doc->isSuccess()) {
//            # Pull off status
//            $coderes = $doc->getCode();
//            $msg = $doc->getElementsByTagName('msg')->item(0)->nodeValue;
//            $values["error"] = "GetNameservers/domain-info($domain): Code ($coderes) $msg";

      return [
        'error' => "Error occurred while getting nameserver details. Kindly try again later.",
      ];
    }

    $nameservers = $doc->dom->getElementsByTagName('hostObj');

    $index = 1;
    $values = [];
    foreach ($nameservers as $nameserver) {
      $values["ns{$index}"] = $nameserver->nodeValue;
      $index++;
    }

    return $values;
  } catch (Exception $e) {
//        $values["error"] = 'GetNameservers/EPP: ' . $e->getMessage();

    return [
      'error' => "Error occurred while getting nameserver details. Contact your system administrator.",
    ];
  }
}

# Function to save the nameservers
function olacv_SaveNameservers($params): array
{
  # Grab variables
  $sld = $params["sld"];
  $tld = $params["tld"];
  $domain = "$sld.$tld";

  # Generate an array of new nameservers
  $nameservers = [];
  if (!empty($params["ns1"])) {
    $nameservers[] = $params["ns1"];
  }
  if (!empty($params["ns2"])) {
    $nameservers[] = $params["ns2"];
  }
  if (!empty($params["ns3"])) {
    $nameservers[] = $params["ns3"];
  }
  if (!empty($params["ns4"])) {
    $nameservers[] = $params["ns4"];
  }
  if (!empty($params["ns5"])) {
    $nameservers[] = $params["ns5"];
  }

  $doc = new EppParser();

  try {
    $client = _olacv_Client();

    for ($i = 0; $i < count($nameservers); $i++) {
      $nameserver = $nameservers[$i];

      $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
   <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
     <command>
       <info>
         <host:info xmlns:host="urn:ietf:params:xml:ns:host-1.0">
           <host:name>' . $nameserver . '</host:name>
         </host:info>
       </info>
       <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
     </command>
   </epp>';

      $result = $client->request($xml);

      $doc->loadXML($result);

      logModuleCall('olacv', 'SaveNameservers', $xml, $result, null, []);

      if ($doc->doesNotExist()) {
        $createXml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
   <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
     <command>
       <create>
         <host:create xmlns:host="urn:ietf:params:xml:ns:host-1.0">
           <host:name>' . $nameserver . '</host:name>        
         </host:create>
       </create>
       <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
     </command>
   </epp>';

        $response = $client->request($createXml);
        logModuleCall('olacv', 'SaveNameservers', $createXml, $response, null, []);

        $create = new EppParser($response);
        if (!$create->isSuccess()) {
          return [
            "error" => "Could not create host($nameserver). Code {$create->getCode()} {$create->getMsg()}"
          ];
        }
      }
    }

    $addHosts = '';
    if ($nameserver1 = $params["ns1"]) {
      $addHosts .= '<domain:hostObj>' . $nameserver1 . '</domain:hostObj>';
    }
    if ($nameserver2 = $params["ns2"]) {
      $addHosts .= '<domain:hostObj>' . $nameserver2 . '</domain:hostObj>';
    }
    if ($nameserver3 = $params["ns3"]) {
      $addHosts .= '<domain:hostObj>' . $nameserver3 . '</domain:hostObj>';
    }
    if ($nameserver4 = $params["ns4"]) {
      $addHosts .= '<domain:hostObj>' . $nameserver4 . '</domain:hostObj>';
    }
    if ($nameserver5 = $params["ns5"]) {
      $addHosts .= '<domain:hostObj>' . $nameserver5 . '</domain:hostObj>';
    }

    $authCode = _olacv_generateAuthCode($domain);
    # Grab the list of current nameservers
    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
   <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
     <command>
       <info>
         <domain:info xmlns:domain="urn:ietf:params:xml:ns:domain-1.0">
            <domain:name hosts="all">' . $domain . '</domain:name>
              <domain:authInfo>
                <domain:pw>' . $authCode . '</domain:pw>
            </domain:authInfo>
         </domain:info>
       </info>
       <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
     </command>
   </epp>';

    $request = $client->request($xml);

    # Parse XML result
    $doc = new EppParser($request);
    if (!$doc->isSuccess()) {
      return [
        "error" => "Could not get domain details($domain) while saving nameservers. {$doc->getCode()}: {$doc->getMsg()}"
      ];
    }

    $values["status"] = $doc->getMsg();

    $hostNodes = $doc->dom->getElementsByTagName('hostObj');
    $removalHosts = '';
    foreach ($hostNodes as $host) {
      $removalHosts .= '<domain:hostObj>' . $host->nodeValue . '</domain:hostObj>';
    }

    # Build request
    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
   <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
     <command>
       <update>
         <domain:update xmlns:domain="urn:ietf:params:xml:ns:domain-1.0">
            <domain:name>' . $domain . '</domain:name>
            <domain:add><domain:ns>' . $addHosts . ' </domain:ns></domain:add>
            <domain:rem><domain:ns>' . $removalHosts . '</domain:ns></domain:rem>
            <domain:authInfo><domain:pw>' . $authCode . '</domain:pw></domain:authInfo>
			</domain:update>
		</update>
		<clTRID>' . mt_rand() . mt_rand() . '</clTRID>
	</command>
</epp>';

    $request = $client->request($xml);
    logModuleCall('olacv', 'SaveNameservers', $xml, $request, null, [$authCode]);

    $doc = new EppParser($request);
    if (!$doc->isSuccess()) {
      return [
        "error" => "Could not update domain nameserver($domain). {$doc->getCode()}: {$doc->getMsg()}"
      ];
    }

    $values['status'] = "Nameservers saved successfully";
    return $values;
  } catch (Exception $e) {
    return [
      "error" => "Error occurred while updating domain nameserver($domain). Message: {$e->getMessage()}"
    ];
  }
}

function olacv_GetRegistrarLock($params)
{
  # Grab variables
  $sld = $params["sld"];
  $tld = $params["tld"];
  $domain = "$sld.$tld";

  try {
    $authCode = _olacv_generateAuthCode($domain);

    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
        <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
          <command>
            <info>
              <domain:info xmlns:domain="urn:ietf:params:xml:ns:domain-1.0">
                <domain:name hosts="all">' . $domain . '</domain:name>
                <domain:authInfo><domain:pw>' . $authCode . '</domain:pw></domain:authInfo>
              </domain:info>
            </info>
            <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
          </command>
        </epp>';

    $client = _olacv_Client();
    $request = $client->request($xml);
    logModuleCall('olacv', 'GetRegistrarLock', $xml, $request, null, [$authCode]);

    $doc = new EppParser($request);
    if (!$doc->isSuccess()) {
      throw new Exception(
        "Unable to get registrar lock for $domain. {$doc->getCode()}): {$doc->getMsg()}"
      );
    }

    $statusNodes = $doc->dom->getElementsByTagName('status');
    if ($statusNodes->length === 0) {
      throw new Exception("No status nodes in EPP response for $domain");
    }

    $currentStatuses = [];
    foreach ($statusNodes as $node) {
      $currentStatuses[] = $node->getAttribute('s');
    }

    return (
      in_array('clientDeleteProhibited', $currentStatuses) ||
      in_array('clientTransferProhibited', $currentStatuses)
    ) ? STATUS_LOCKED : STATUS_UNLOCKED;
  } catch (Exception $e) {
    return ["error" => $e->getMessage()];
  }
}

function olacv_SaveRegistrarLock($params): array
{
  $lockedStatus = "locked";
  $unlockedStatus = "unlocked";

  $lockStatus = olacv_GetRegistrarLock($params);

  if ($lockStatus == $unlockedStatus && $params["lockenabled"] == $lockedStatus) {
    return olacv_LockDomain($params);
  } elseif ($lockStatus == $lockedStatus && $params["lockenabled"] == $unlockedStatus) {
    return olacv_UnlockDomain($params);
  } else {
    $values["error"] = "SaveRegistrar LOCK: Domain Status unknown ";
    return $values;
  }
}

function olacv_LockDomain($params): array
{
  $sld = $params["sld"];
  $tld = $params["tld"];
  $domain = "$sld.$tld";

  try {
    $client = _olacv_Client();
    $authCode = _olacv_generateAuthCode($domain);

    //Less restrictive locks
    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
        <epp xmlns="urn:ietf:params:xml:ns:epp-1.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
          <command>
            <update>
              <domain:update xmlns:domain="urn:ietf:params:xml:ns:domain-1.0" xsi:schemaLocation="urn:ietf:params:xml:ns:domain-1.0 domain-1.0.xsd">
                <domain:name>' . $domain . '</domain:name>
                  <domain:add>
                    <domain:status s="clientDeleteProhibited"/>
                    <domain:status s="clientTransferProhibited"/>
                  </domain:add>
                <domain:authInfo><domain:pw>' . $authCode . '</domain:pw></domain:authInfo>
              </domain:update>
            </update>
            <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
          </command>
        </epp>';
    $values = [];

    $request = $client->request($xml);
    logModuleCall('olacv', 'Lock-Delete-Transfer', $xml, $request, [], [$authCode]);

    $parser = new EppParser($request);
    if (!$parser->isSuccess()) {
      $values["error"] = "Lock Domain($domain): Code (" . $parser->getCode() . ") " . $parser->getMsg();
      return $values;
    }
  } catch (Exception $e) {
    $values["error"] = 'Domain Lock/EPP: ' . $e->getMessage();
    return $values;
  }

  return $values;
}

function olacv_UnlockDomain($params)
{
  # Grab variables
  $sld = $params["sld"];
  $tld = $params["tld"];
  $domain = "$sld.$tld";

  try {
    $client = _olacv_Client();

    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
		<epp xmlns="urn:ietf:params:xml:ns:epp-1.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
		  <command>
        <update>
          <domain:update xmlns:domain="urn:ietf:params:xml:ns:domain-1.0" xsi:schemaLocation="urn:ietf:params:xml:ns:domain-1.0 domain-1.0.xsd">
            <domain:name>' . $domain . '</domain:name>
            <domain:rem>
              <domain:status s="clientUpdateProhibited"/>
            </domain:rem>
          </domain:update>
        </update>
        <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
		  </command>
		</epp>
		';

    $values = [];

    $request = $client->request($xml);
    logModuleCall('olacv', 'Remove UpdateProhibited', $xml, $request, null, []);

    $parser = new EppParser($request);
    if (!$parser->isSuccess()) {
      return [
        'error' => 'Failed to remove client update prohibition.'
      ];
    }

    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
		<epp xmlns="urn:ietf:params:xml:ns:epp-1.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
		  <command>
			<update>
			  <domain:update xmlns:domain="urn:ietf:params:xml:ns:domain-1.0" xsi:schemaLocation="urn:ietf:params:xml:ns:domain-1.0 domain-1.0.xsd">
				<domain:name>' . $domain . '</domain:name>
				<domain:rem>
				  <domain:status s="clientDeleteProhibited"/>
				  <domain:status s="clientTransferProhibited"/>
				  <domain:status s="clientRenewProhibited"/>
				</domain:rem>
			  </domain:update>
			</update>
			<clTRID>' . mt_rand() . mt_rand() . '</clTRID>
		  </command>
		</epp>
		';
    $request = $client->request($xml);
    logModuleCall('olacv', 'Domain UnLock', $xml, $request, null, []);

    $parser = new EppParser($request);
    if (!$parser->isSuccess()) {
//      $values["error"] = "Domain Unlock($sld.$tld): Code (" . $parser->getCode() . ") " . $parser->getMsg();
      return [
        'error' => 'Failed to remove other client prohibitions.'
      ];
    }

    return $values;
  } catch (Exception $e) {
//    $values["error"] = 'Domain UnLock/EPP: ' . $e->getMessage();
//    return $values;
    return [
      'error' => 'Domain unlock failed.' . $e->getMessage()
    ];
  }
}

# Function to register domain
function olacv_RegisterDomain($params): array
{
  # Grab variables
  $sld = $params["sld"];
  $tld = $params["tld"];
  $period = $params["regperiod"];
  $domain = "$sld.$tld";

  # Get registrant details
  $RegistrantFirstName = $params["firstname"];
  $RegistrantLastName = $params["lastname"];
  $RegistrantAddress1 = $params["address1"];
  $RegistrantAddress2 = $params["address2"];
  $RegistrantCity = $params["city"];
  $RegistrantStateProvince = $params["state"];
  $RegistrantPostalCode = $params["postcode"];
  $RegistrantCountry = $params["country"];
  $RegistrantEmailAddress = $params["email"];
  $RegistrantPhone = $params["fullphonenumber"];

  #Generate Handle
  $registrantHandle = _olacv_generateHandle();

  # Get admin details
  $AdminFirstName = $params["adminfirstname"];
  $AdminLastName = $params["adminlastname"];
  $AdminAddress1 = $params["adminaddress1"];
  $AdminAddress2 = $params["adminaddress2"];
  $AdminCity = $params["admincity"];
  $AdminStateProvince = $params["adminstate"];
  $AdminPostalCode = $params["adminpostcode"];
  $AdminCountry = $params["admincountry"];
  $AdminEmailAddress = $params["adminemail"];
  $AdminPhone = $params["adminphonenumber"];
  $RegistrantOrganizationName = $params["companyname"];

  /**
   * Premium domain parameters.
   *
   * Premium domains enabled informs you if the admin user has enabled
   * the selling of premium domain names. If this domain is a premium name,
   * `premiumCost` will contain the cost price retrieved at the time of
   * the order being placed. The premium order should only be processed
   * if the cost price now matches the previously fetched amount.
   */
  $premiumDomainsEnabled = (bool)($params['premiumEnabled'] ?? false);
  $premiumDomainsCost = $params['premiumCost'];

  $adminHandle = _olacv_generateHandle();

  # Generate an array of new nameservers
  $nameservers = [];
  if (!empty($params["ns1"])) {
    $nameservers[] = $params["ns1"];
  }
  if (!empty($params["ns2"])) {
    $nameservers[] = $params["ns2"];
  }
  if (!empty($params["ns3"])) {
    $nameservers[] = $params["ns3"];
  }
  if (!empty($params["ns4"])) {
    $nameservers[] = $params["ns4"];
  }
  if (!empty($params["ns5"])) {
    $nameservers[] = $params["ns5"];
  }

  try {
    $client = _olacv_Client();
    for ($i = 0; $i < count($nameservers); $i++) {
      # Get a list of nameservers for domain(
      $requestXml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
   <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
     <command>
       <info>
         <host:info xmlns:host="urn:ietf:params:xml:ns:host-1.0">
           <host:name>' . $nameservers[$i] . '</host:name>
         </host:info>
       </info>
       <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
     </command>
   </epp>';
      $result = $client->request($requestXml);
      logModuleCall('olacv', 'GetNameservers', $requestXml, $result, null, []);

      # Parse XML result
      $doc = new EppParser($result);
      if ($doc->doesNotExist()) {
        $createXml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
   <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
     <command>
       <create>
         <host:create xmlns:host="urn:ietf:params:xml:ns:host-1.0">
           <host:name>' . $nameservers[$i] . '</host:name>        
         </host:create>
       </create>
       <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
     </command>
   </epp>';
        $request = $client->request($createXml);
        logModuleCall('olacv', 'SaveNameservers', $createXml, $request, null, []);

        # Parse XML result
        $doc = new EppParser($request);
        if (!$doc->isSuccess()) {
          return [
            'error' => "Failed to create host($nameservers[$i]). Code({$doc->getCode()}): {$doc->getMsg()}"
          ];
        }
      }
    }

    // End create nameservers

    $addHosts = '';
    # Generate XML for nameservers
    if ($nameserver1 = $params["ns1"]) {
      $addHosts .= '<domain:hostObj>' . $nameserver1 . '</domain:hostObj>';
    }
    if ($nameserver2 = $params["ns2"]) {
      $addHosts .= '<domain:hostObj>' . $nameserver2 . '</domain:hostObj>';
    }
    if ($nameserver3 = $params["ns3"]) {
      $addHosts .= '<domain:hostObj>' . $nameserver3 . '</domain:hostObj>';
    }
    if ($nameserver4 = $params["ns4"]) {
      $addHosts .= '<domain:hostObj>' . $nameserver4 . '</domain:hostObj>';
    }
    if ($nameserver5 = $params["ns5"]) {
      $addHosts .= '<domain:hostObj>' . $nameserver5 . '</domain:hostObj>';
    }

    # Create Registrant
    $authCode = _olacv_authKey();
    $requestXml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
    <command>
        <create>
            <contact:create xmlns:contact="urn:ietf:params:xml:ns:contact-1.0">
                <contact:id>' . $registrantHandle . '</contact:id>
                <contact:postalInfo type="int">
                    <contact:name>' . $RegistrantFirstName . ' ' . $RegistrantLastName . '</contact:name>
                    <contact:org>' . $RegistrantOrganizationName . '</contact:org>
                    <contact:addr>
                        <contact:street>' . $RegistrantAddress1 . '</contact:street>
                        <contact:street>' . $RegistrantAddress2 . '</contact:street>
                        <contact:city>' . $RegistrantCity . '</contact:city>
                        <contact:sp>' . $RegistrantStateProvince . '</contact:sp>
                        <contact:pc>' . $RegistrantPostalCode . '</contact:pc>
                        <contact:cc>' . $RegistrantCountry . '</contact:cc>
                    </contact:addr>
                </contact:postalInfo>
                <contact:voice x="">' . $params["phonenumber"] . '</contact:voice>
                <contact:fax></contact:fax>
                <contact:email>' . $RegistrantEmailAddress . '</contact:email>
                <contact:authInfo>
                    <contact:pw>olaCV' . $authCode . '</contact:pw>
                </contact:authInfo>
            </contact:create>
        </create>

        <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
    </command>
</epp>
';
    $request = $client->request($requestXml);

    $doc = new EppParser($request);
    # Pull off status
    $msg = $doc->getMsg();

    if ($doc->isSuccess()) {
      $values['contact'] = 'Registrant created';
    } elseif ($doc->existsAlready()) {
      $values['contact'] = 'Contact already exists';
    } else {
      return [
        'error' => "Failed to create contact account($registrantHandle). Code({$doc->getCode()}): {$msg}"
      ];

//            $values["error"] = "RegisterDomain/Reg-create($registrantHandle): Code ($coderes) $msg";
//            return $values;
    }

    $values["status"] = $msg;
    $authCode = _olacv_authKey();

    $requestXml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
    <command>
        <create>
            <contact:create xmlns:contact="urn:ietf:params:xml:ns:contact-1.0">
                <contact:id>' . $adminHandle . '</contact:id>
                <contact:postalInfo type="int">
                    <contact:name>' . $AdminFirstName . ' ' . $AdminLastName . '</contact:name>
                    <contact:addr>
                        <contact:street>' . $AdminAddress1 . '</contact:street>
                        <contact:street>' . $AdminAddress2 . '</contact:street>
                        <contact:city>' . $AdminCity . '</contact:city>
                        <contact:sp>' . $AdminStateProvince . '</contact:sp>
                        <contact:pc>' . $AdminPostalCode . '</contact:pc>
                        <contact:cc>' . $AdminCountry . '</contact:cc>
                    </contact:addr>
                </contact:postalInfo>
                <contact:voice>' . $AdminPhone . '</contact:voice>
                <contact:fax></contact:fax>
                <contact:email>' . $AdminEmailAddress . '</contact:email>
                <contact:authInfo><contact:pw>olaCV' . $authCode . '</contact:pw></contact:authInfo>
            </contact:create>
        </create>
        <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
    </command>
</epp>';

    //Create Domain Admin
    $request = $client->request($requestXml);

    # Parse XML result
    $doc = new EppParser($request);
    if ($doc->isSuccess()) {
      $values['contact'] = 'Admin contact created';
    } elseif ($doc->existsAlready()) {
      $values['contact'] = 'Admin contact already exists';
    } else {
      return [
        'error' => "Failed to create admin contact account($adminHandle) for $domain. Code({$doc->getCode()}): {$doc->getMsg()}"
      ];

//            $values["error"] = "RegisterDomain/Reg-create($registrantHandle): Code ($coderes) $msg";
//            return $values;
    }

    $authCode = _olacv_generateAuthCode($domain);
    $values["status"] = $doc->getMsg();

    $extensions = '';
    if ($premiumDomainsEnabled && $premiumDomainsCost) {
      $extensions = '<extension>
      <fee:create xmlns:fee="urn:ietf:params:xml:ns:fee-0.7">
        <fee:currency>USD</fee:currency>
        <fee:fee>743.75</fee:fee>
      </fee:create>
    </extension>';
    }

    $requestXml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
    <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
        <command>
            <create>
                <domain:create xmlns:domain="urn:ietf:params:xml:ns:domain-1.0">
                    <domain:name>' . $sld . '.' . $tld . '</domain:name>
                    <domain:period unit="y">' . $period . '</domain:period>
                    <domain:ns>' . $addHosts . '</domain:ns>
                    <domain:registrant>' . $registrantHandle . '</domain:registrant>
                    <domain:contact type="admin">' . $adminHandle . '</domain:contact>
                    <domain:contact type="tech">' . $adminHandle . '</domain:contact>
                    <domain:contact type="billing">' . $adminHandle . '</domain:contact>
                    <domain:authInfo><domain:pw>olaCV' . $authCode . '</domain:pw></domain:authInfo>
                </domain:create>
            </create>
            <clTRID>' . mt_rand() . mt_rand() . '</clTRID>	
        </command>
    </epp>';

    $request = $client->request($requestXml);
    logModuleCall('olacv', 'RegisterDomain', $requestXml, $request, null, []);

    $doc = new EppParser($request);
    if (!$doc->isSuccess()) {
      return [
        'error' => "Failed to create domain $domain. Code({$doc->getCode()}): {$doc->getMsg()}"
      ];

//            $values["error"] = "RegisterDomain/domain-create($sld.$tld): Code ($coderes) $msg";
//            return $values;
    }

    $values["status"] = $doc->getMsg();
    return $values;
  } catch (Exception $e) {
    $values["error"] = 'RegisterDomain/EPP: ' . $e->getMessage();
    return $values;
  }
}

# Function to transfer a domain
function olacv_TransferDomain($params)
{
  # Grab variables
  $sld = $params["sld"];
  $tld = $params["tld"];
  $domain = "$sld.$tld";

  # Domain info
  $transfersecret = $params["transfersecret"];


  # Get client instance
  try {
    $client = _olacv_Client();

    # Initiate transfer
    $request = $client->request(
      $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
    <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
    <command>
        <transfer op="request">
            <domain:transfer xmlns:domain="urn:ietf:params:xml:ns:domain-1.0">
                <domain:name>' . $sld . '.' . $tld . '</domain:name>
                <domain:authInfo><domain:pw>' . $transfersecret . '</domain:pw></domain:authInfo>
            </domain:transfer>
        </transfer>
        <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
    </command>
    </epp>'
    );

    # Parse XML result
    $doc = new EppParser($request);
    logModuleCall('olacv', 'TransferDomain', $xml, $request, null, []);

    $msg = $doc->getMsg();
    if (!$doc->isSuccess()) {
      $values["error"] = "TransferDomain/domain-transfer($domain): Code ({$doc->getCode()}) $msg";
      return $values;
    }

    $values["status"] = $msg;
    return $values;
  } catch (Exception $e) {
    $values["error"] = 'TransferDomain/EPP: ' . $e->getMessage();
    return $values;
  }
}

# Function to renew domain
function olacv_RenewDomain($params)
{
# Grab variables
  $sld = $params["sld"];
  $tld = $params["tld"];
  $regperiod = $params["regperiod"];
  $domain = "$sld.$tld";

  try {
    $client = _olacv_Client();

    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
            <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
                <command>
                    <info>
                        <domain:info xmlns:domain="urn:ietf:params:xml:ns:domain-1.0">
                            <domain:name>' . $domain . '</domain:name>
                        </domain:info>
                    </info>
                    <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
                </command>
            </epp>';

    # Send renewal request
    $request = $client->request($xml);
    logModuleCall('olacv', 'RenewDomain', $xml, $request, null, []);

    # Parse XML result
    $parser = new EppParser($request);

    $msg = $parser->dom->getElementsByTagName('msg')->item(0)->nodeValue;

    if (!$parser->isSuccess()) {
      $values["error"] = "RenewDomain/domain-info($domain)): Code ({$parser->getCode()}) {$parser->getMsg()}";
      return $values;
    }

    // check domain status
    if ($parser->dom->getElementsByTagName('status')->item(0)) {
      $statusres = $parser->dom->getElementsByTagName('status')->item(0)->getAttribute('s');
      $requestedby = $parser->dom->getElementsByTagName('status')->item(0)->nodeValue;
      $createdate = substr($parser->dom->getElementsByTagName('crDate')->item(0)->nodeValue, 0, 10);
      $nextduedate = substr($parser->dom->getElementsByTagName('exDate')->item(0)->nodeValue, 0, 10);
      $deldate = $parser->dom->getElementsByTagName('upDate')->item(0)->nodeValue;
      $currdate1 = date("Y-m-d");
      $currdate2 = date("H:i:s");
    } else {
      $values['error'] = "RenewDomain/domain-info($domain): Domain not found";
      return $values;
    }

    $values['status'] = $msg;
    # Sanitize expiry date
    $expdate = substr($parser->dom->getElementsByTagName('exDate')->item(0)->nodeValue, 0, 10);
    if (empty($expdate)) {
      $values["error"] = "RenewDomain/domain-info($sld.$tld): Domain info not available";
      return $values;
    }

    # Check if domain in pendingdelete state then send a restore command with restore report
    if ($statusres == STATUS_PENDING_DELETE) {
      // $values['error'] = "RenewDomain/domain-info($domain): Domain Status :pendingDelete";
      // here will send restore command
      $restore_request = $client->request(
        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
                                           <epp xmlns="urn:ietf:params:xml:ns:epp-1.0"
                                                        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                                                        xsi:schemaLocation="urn:ietf:params:xml:ns:epp-1.0
                                                        epp-1.0.xsd">
                                                 <command>
                                                   <update>
                                                         <domain:update
                                                          xmlns:domain="urn:ietf:params:xml:ns:domain-1.0"
                                                          xsi:schemaLocation="urn:ietf:params:xml:ns:domain-1.0
                                                          domain-1.0.xsd">
                                                           <domain:name>' . $sld . '.' . $tld . '</domain:name>
                                                           <domain:chg/>
                                                         </domain:update>
                                                   </update>
                                                   <extension>
                                                         <rgp:update xmlns:rgp="urn:ietf:params:xml:ns:rgp-1.0"
                                                          xsi:schemaLocation="urn:ietf:params:xml:ns:rgp-1.0
                                                          rgp-1.0.xsd">
                                                           <rgp:restore op="report">
                                                                 <rgp:report>
                                                                   <rgp:preData>Registrant did not Renew domain name
                                                                   in Renewal Grace Period.</rgp:preData>
                                                                   <rgp:postData>I am not restoring this domain name
                                                                   in order to assume the rights to use or sell the
                                                                   domain name for myself or for any third party. The
                                                                   domain name will be returned to the control of its
                                                                   former registrant.</rgp:postData>
                                                                   <rgp:delTime>' . $deldate . '</rgp:delTime>
                                                                   <rgp:resTime>' . $currdate1 . 'T' . $currdate2 . '.675Z</rgp:resTime>
                                                                   <rgp:resReason>Registrant error.</rgp:resReason>
                                                                   <rgp:statement>This registrar has not restored the
                                                                   Registered Name in order to assume the rights to use
                                                                   or sell the Registered Name for itself or for any
                                                                   third party.</rgp:statement>
                                                                   <rgp:statement>The information in this report is
                                                                   true to best of this registrars knowledge, and this
                                                                   registrar acknowledges that intentionally supplying
                                                                   false information in this report shall constitute an
                                                                   incurable material breach of the
                                                                   Registry-Registrar Agreement.</rgp:statement>
                                                                   <rgp:other>Supporting information goes
                                                                   here.</rgp:other>
                                                                 </rgp:report>
                                                           </rgp:restore>
                                                         </rgp:update>
                                                   </extension>
                                                   <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
                                                 </command>
                                           </epp>'
      );
      # Parse XML restore result
      $parser = new EppParser($restore_request);
      logModuleCall('olacv', 'RestoreDomain', $xml, $request, null, []);

      $coderes = $parser->getCode();
      $msg = $parser->getMsg();
      if (!$parser->isSuccess()) {
        $values["error"] = "RenewDomain/Restore domain-info($sld.$tld)): Code ($coderes) $msg";
        return $values;
      }
    }
    //
    $values['status'] = $msg;
    # Send request to renew
    $request = $client->request(
      $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
    <command>
        <renew>
            <domain:renew xmlns:domain="urn:ietf:params:xml:ns:domain-1.0">
                <domain:name>' . $sld . '.' . $tld . '</domain:name>
                <domain:curExpDate>' . $expdate . '</domain:curExpDate>
                <domain:period unit="y">' . $regperiod . '</domain:period>
            </domain:renew>
        </renew>
    </command>
    <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
</epp>'
    );
    logModuleCall('olacv', 'RenewDomain', $xml, $request, null, []);

    # Parse XML result
    $parser = new EppParser($request);
    $msg = $parser->getMsg();

    if (!$parser->isSuccess()) {
      $values["error"] = "RenewDomain/domain-renew($sld.$tld,$expdate): Code (" . $parser->getCode() . ") " . $msg;
      return $values;
    }

    $values["status"] = $msg;
  } catch (Exception $e) {
    $values["error"] = 'RenewDomain/EPP: ' . $e->getMessage();
    return $values;
  }

  # If error, return the error message in the value below
  return $values;
}

# Function to grab contact details
function olacv_GetContactDetails($params)
{
  # Grab variables
  $sld = $params["sld"];
  $tld = $params["tld"];

  $domain = "$sld.$tld";

  try {
    $client = _olacv_Client();
    $authcode = _olacv_generateAuthCode($domain);
    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<epp xmlns="urn:ietf:params:xml:ns:epp-1.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <command>
    <info>
      <domain:info xmlns:domain="urn:ietf:params:xml:ns:domain-1.0" xsi:schemaLocation="urn:ietf:params:xml:ns:domain-1.0 domain-1.0.xsd">
        <domain:name>' . $domain . '</domain:name>
		    <domain:authInfo>
		        <domain:pw>' . _olacv_generateAuthCode($domain) . '</domain:pw>
            </domain:authInfo>
      </domain:info>
    </info>
    <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
  </command>
</epp>';
    # Grab domain info
    $result = $client->request($xml);
    logModuleCall('olacv', 'GetContactDetails', $xml, $result, null, [$authcode]);

    $parser = new EppParser($result);
    if (!$parser->isSuccess()) {
      return [
        "error" => "Error occurred while fetching details ($domain) for contact info."
      ];
    }

    # Grab contact Handles
    $registrant = $parser->queryValue('//domain:registrant');
    if (empty($registrant)) {
      return [
        "error" => "GetContactDetails/domain-info($domain): Registrant info not available"
      ];
    }

    $domainInfo = [];
    for ($i = 0; $i <= 2; $i++) {
      $x = $parser->dom->getElementsByTagName('contact')->item($i);

      if (!empty($x)) {
        $domainInfo[$x->getAttribute('type')] = $x->nodeValue;
      } else {
        break;
      }
    }

    $contactIDs[$registrant] = [];
    foreach ($domainInfo as $id) {
      if ($id != '') {
        $contactIDs[$id] = [];
      }
    }
    foreach ($contactIDs as $id => $k) {
      $contactIDs[$id] = _olacv_getContactDetail($client, $id);
    }

    $contacts["Admin"] = $domainInfo["admin"];
    $contacts["Tech"] = $domainInfo["tech"];
    $contacts["Billing"] = $domainInfo["billing"];

    # Grab Registrant Contact
    $values["Registrant"] = $contactIDs[$registrant];

    #Get Admin, Tech and Billing Contacts
    foreach ($contacts as $type => $value) {
      if ($value != "") {
        $values["$type"] = $contactIDs[$value];
      } else {
        $values["$type"]["Contact Name"] = "";
        $values["$type"]["Company Name"] = "";
        $values["$type"]["Address 1"] = "";
        $values["$type"]["Address 2"] = "";
        $values["$type"]["City"] = "";
        $values["$type"]["State"] = "";
        $values["$type"]["ZIP code"] = "";
        $values["$type"]["Country"] = "";
        $values["$type"]["Phone"] = "";
        $values["$type"]["Email"] = "";
      }
    }

    return $values;
  } catch (Exception $e) {
    $values["error"] = 'GetContactDetails/EPP: ' . $e->getMessage();
    return $values;
  }
}

# Function to save contact details
function olacv_SaveContactDetails($params)
{
  # Grab variables
  $tld = $params["tld"];
  $sld = $params["sld"];
  $details = $params["contactdetails"];
  $domain = "$sld.$tld";

  try {
    $client = _olacv_Client();

    # Grab domain info
    $request = $client->request(
      $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<epp:epp xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:epp="urn:ietf:params:xml:ns:epp-1.0"
		xmlns:domain="urn:ietf:params:xml:ns:domain-1.0" xsi:schemaLocation="urn:ietf:params:xml:ns:epp-1.0 epp-1.0.xsd">
	<epp:command>
		<epp:info>
			<domain:info xsi:schemaLocation="urn:ietf:params:xml:ns:domain-1.0 domain-1.0.xsd">
				<domain:name hosts="all">' . $domain . '</domain:name>
		    <domain:authInfo><domain:pw>' . _olacv_generateAuthCode($domain) . '</domain:pw></domain:authInfo>
			</domain:info>
		</epp:info>
	</epp:command>
</epp:epp>'
    );

    logModuleCall('olacv', 'SaveContactDetails', $xml, $request, null, []);
    # Parse XML	result
    $doc = new EppParser($request);

    $coderes = $doc->getCode();
    $msg = $doc->getElementsByTagName('msg')->item(0)->nodeValue;
    if (!$doc->isSuccess()) {
      $values["error"] = "SaveContactDetails/domain-info($domain): Code (" . $coderes . ") " . $msg;
      return $values;
    }

    $values["status"] = $msg;
    # Grab Registrant contact Handles
    $registrantHandle = $doc->getElementsByTagName('registrant')->item(0)->nodeValue;
    if (empty($registrantHandle)) {
      $values["error"] = "GetContactDetails/domain-info($domain): Registrant info not available";
      return $values;
    }

    $domainInfo = [];
    for ($i = 0; $i <= 2; $i++) {
      $x = $doc->getElementsByTagName('contact')->item($i);
      if (!empty($x)) {
        $domainInfo[$doc->getElementsByTagName('contact')->item($i)->getAttribute(
          'type'
        )] = $doc->getElementsByTagName('contact')->item($i)->nodeValue;
      } else {
        break;
      }
    }

    $Contacts["Admin"] = $domainInfo["admin"];
    $Contacts["Tech"] = $domainInfo["tech"];
    $Contacts["Billing"] = $domainInfo["billing"];

    $cIDs[$registrantHandle] = 'Registrant';
    foreach ($Contacts as $type => $handle) {
      if (isset($handle)) {
        if (!array_key_exists($handle, $cIDs)) {
          $cIDs[$handle] = $type;
        } else {
          $removeContact[$type] = $handle;
          $Contacts[$type] = null;
        }
      }
    }

    foreach ($Contacts as $type => $handle) {
      $notEmpty = !_olacv_array_empty($details[$type]);

      if (isset($handle)) {
        if ($notEmpty) {
          _olacv_changeContact($client, $details[$type], $handle, $type);
        } else {
          $removeContact[$type] = $handle;
        }
      } else {
        if ($notEmpty) {
          $addContact[$type] = olacv_createContact($client, $details[$type], $type);
        }
      }
    }

    $xmlAddContact = '';
    if (isset($addContact)) {
      $xmlAddContact = "<domain:add>\n";
      foreach ($addContact as $type => $handle) {
        $xmlAddContact .= '<domain:contact type="' . strtolower(
            $type
          ) . '">' . $handle . '</domain:contact>' . "\n";
      }
      $xmlAddContact .= "</domain:add>\n";
    }

    $xmlRemContact = '';
    if (isset($removeContact)) {
      $xmlRemContact = "<domain:rem>\n";
      foreach ($removeContact as $type => $handle) {
        $xmlRemContact .= '<domain:contact type="' . strtolower(
            $type
          ) . '">' . $handle . '</domain:contact>' . "\n";
      }
      $xmlRemContact .= "</domain:rem>\n";
    }

    # Save Registrant contact details
    _olacv_changeContact($client, $details['Registrant'], $registrantHandle, "Registrant");

    # change the domain contacts
    if (!empty($xmlAddContact) || !empty($xmlRemContact)) {
      $request = $client->request(
        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
  <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
    <command>
      <update>
        <domain:update xmlns:domain="urn:ietf:params:xml:ns:domain-1.0">
         <domain:name>' . $domain . '</domain:name>
		    <domain:authInfo><domain:pw>' . _olacv_generateAuthCode($domain) . '</domain:pw></domain:authInfo> ' .
          $xmlAddContact .
          $xmlRemContact . '
        </domain:update>
       </update>
       <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
     </command>
   </epp>'
      );

      $doc = new EppParser($request);
      logModuleCall('olacv', 'SaveContactDetails', $xml, $request, null, []);

      $coderes = $doc->getCode();
      $msg = $doc->getElementsByTagName('msg')->item(0)->nodeValue;
      if (!$doc->isSuccess()) {
        $values["error"] = "Domain contact update error: Code ($coderes) $msg";
        return $values;
      }

      $values["status"] = $msg;
    } else {
      $values["status"] = 'OK';
    }
  } catch (Exception $e) {
    $values["error"] = 'SaveContactDetails/EPP: ' . $e->getMessage();
    return $values;
  }

  return $values;
}

function olacv_createContact($client, $data, $type = "")
{
  //Create Billing Contacts
  $handle = _olacv_generateHandle();
  $eppKey = _olacv_authKey();

  $result = $client->request(
    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
  <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
    <command>
      <create>
        <contact:create xmlns:contact="urn:ietf:params:xml:ns:contact-1.0">
          <contact:id>' . $handle . '</contact:id>
          <contact:postalInfo type="int">
            <contact:name>' . $data["Contact Name"] . ' </contact:name>
            <contact:org>' . $data["Company Name"] . '</contact:org>
            <contact:addr>
              <contact:street>' . $data["Address 1"] . '</contact:street>
              <contact:street>' . $data["Address 2"] . '</contact:street>
              <contact:city>' . $data["City"] . '</contact:city>
              <contact:sp>' . $data["State"] . '</contact:sp>
              <contact:pc>' . $data["ZIP code"] . '</contact:pc>
              <contact:cc>' . $data["Country"] . '</contact:cc>
            </contact:addr>
          </contact:postalInfo>
          <contact:voice>' . $data["Phone"] . '</contact:voice>
          <contact:email>' . $data["Email"] . '</contact:email>
          <contact:authInfo>
            <contact:pw>olaCV' . $eppKey . '</contact:pw>
          </contact:authInfo>
        </contact:create>
      </create>
      <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
	</command>
  </epp>'
  );

  # Parse XML result
  $doc = new EppParser($result);
  logModuleCall('olacv', 'SaveContactDetails', $xml, $result, null, []);

  $coderes = $doc->getCode();
  $msg = $doc->getElementsByTagName('msg')->item(0)->nodeValue;
  if (!$doc->isSuccess()) {
    throw new Exception("contact-create($handle) $type: Code ($coderes) $msg");
  }

  return $handle;
}

# Function to get EPP Code
function olacv_GetEPPCode($params)
{
  # Grab variables
  $sld = $params["sld"];
  $tld = $params["tld"];

  $domain = $sld . '.' . $tld;
  $newEppKey = _olacv_generateAuthCode($domain);

  try {
    $client = _olacv_Client();

    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
			<epp xmlns="urn:ietf:params:xml:ns:epp-1.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="urn:ietf:params:xml:ns:epp-1.0 epp-1.0.xsd">
			<command>
                <update>
                    <domain:update xmlns:domain="urn:ietf:params:xml:ns:domain-1.0" xsi:schemaLocation="urn:ietf:params:xml:ns:domain-1.0 domain-1.0.xsd">
                        <domain:name>' . $domain . '</domain:name>
                        <domain:chg>
                            <domain:authInfo>
                                <domain:pw>' . $newEppKey . '</domain:pw>
                            </domain:authInfo>
                        </domain:chg>
                    </domain:update>
                </update>
			    <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
			</command>
			</epp>';

    $response = $client->request($xml);
    logModuleCall('olacv', 'GetEppCode', $xml, $response, null, [$newEppKey]);

    $doc = new EppParser($response);

    # If error, return the error message in the value below
    $msg = $doc->getElementsByTagName('msg')->item(0)->nodeValue;

    if (!$doc->isSuccess()) {
      $values["error"] = "Authcode/EPP($sld.$tld): Code ({$doc->getCode()}) $msg";
      return $values;
    }

    return [
      'eppcode' => $newEppKey,
      'status' => $msg
    ];
  } catch (Exception $e) {
    $values["error"] = 'Authcode/EPP: ' . $e->getMessage();
    return $values;
  }
}

# Function to register nameserver
function olacv_RegisterNameserver($params)
{
  # Grab variables
  $sld = $params["sld"];
  $tld = $params["tld"];
  $nameserver = $params["nameserver"];
  $ipaddress = $params["ipaddress"];
  $domain = "$sld.$tld";

  try {
    $client = _olacv_Client();

    $nsver = _olacv_detectIpVersion($ipaddress);
    if ($nsver === 'IPv4') {
      $ns = '<host:name>' . $nameserver . '</host:name>' . '<host:addr ip="v4">' . $ipaddress . '</host:addr>';
    } elseif ($nsver === 'IPv6') {
      $ns = '<host:name>' . $nameserver . '</host:name>' . '<host:addr ip="v6">' . $ipaddress . '</host:addr>';
    } else {
      throw new Exception('The IP address is neither IPV4 nor IPV6');
    }

    # Register nameserver
    $request = $client->request(
      $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
   <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
     <command>
       <create>
         <host:create xmlns:host="urn:ietf:params:xml:ns:host-1.0">' . $ns . '</host:create>
       </create>
       <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
     </command>
   </epp>
'
    );
    logModuleCall('olacv', 'RegisterNameserver', $xml, $request, null, []);

    # Parse XML result
    $doc = new EppParser($request);

    $msg = $doc->getMsg();
//    logModuleCall('olacv', 'SaveHost', $xml, $request, null, []);

    if (!$doc->isSuccess()) {
      $values["error"] = "RegisterNameserver($nameserver): Code ({$doc->getCode()}) $msg";
      return $values;
    }

    $values['status'] = $msg;
  } catch (Exception $e) {
    $values["error"] = 'SaveNameservers/EPP: ' . $e->getMessage();
    return $values;
  }

  return $values;
}

# Modify nameserver
function olacv_ModifyNameserver($params)
{
  $nameserver = $params["nameserver"];
  $currentipaddress = $params["currentipaddress"];
  $newipaddress = $params["newipaddress"];

  try {
    $client = _olacv_Client();

    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
   <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
     <command>
       <update>
         <host:update xmlns:host="urn:ietf:params:xml:ns:host-1.0">
           <host:name>' . $nameserver . '</host:name>
           <host:add>
             <host:addr ip="v4">' . $newipaddress . '</host:addr>
           </host:add>
           <host:rem>
             <host:addr ip="v4">' . $currentipaddress . '</host:addr>
           </host:rem>           
         </host:update>
       </update>
       <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
     </command>
   </epp>';

    $response = $client->request($xml);

    $doc = new EppParser($response);
    logModuleCall('olacv', 'ModifyNameserver', $xml, $response, null, []);

    if (!$doc->isSuccess()) {
      return [
        'error' => "Could not modify nameserver($nameserver); {$doc->getMsg()}"
      ];
    }

    $values['status'] = $doc->getMsg();
  } catch (Exception $e) {
    return [
      'error' => "Error occurred while modifying nameserver($nameserver). {$e->getMessage()}"
    ];
  }

  return $values;
}

# Delete nameserver
function olacv_DeleteNameserver($params)
{
  # Grab variables
  $tld = $params["tld"];
  $sld = $params["sld"];
  $nameserver = $params["nameserver"];

  $domain = "$sld.$tld";
  try {
    $client = _olacv_Client();


    # Delete nameserver
    $request = $client->request(
      $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
   <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
     <command>
       <delete>
         <host:delete
          xmlns:host="urn:ietf:params:xml:ns:host-1.0">
           <host:name>' . $nameserver . '</host:name>
         </host:delete>
       </delete>
       <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
     </command>
   </epp>
'
    );
    logModuleCall('olacv', 'DeleteNameserver', $xml, $request, null, []);

    # Parse XML result
    $doc = new EppParser($request);

    $coderes = $doc->getCode();
    $msg = $doc->getElementsByTagName('msg')->item(0)->nodeValue;

    if (!$doc->isSuccess()) {
      $values["error"] = "DeleteNameserver/domain-update($sld.$tld): Code ($coderes) $msg";
      return $values;
    }

    $values['status'] = $msg;
  } catch (Exception $e) {
    $values["error"] = 'SaveNameservers/EPP: ' . $e->getMessage();
    return $values;
  }

  return $values;
}

function olacv_TransferSync($params)
{
  $domainid = $params['domainid'];
  $domain = $params['domain'];
  $sld = $params['sld'];
  $tld = $params['tld'];
  $registrar = $params['registrar'];
  $regperiod = $params['regperiod'];
  $status = $params['status'];
  $dnsmanagement = $params['dnsmanagement'];
  $emailforwarding = $params['emailforwarding'];
  $idprotection = $params['idprotection'];
  $domain = "$sld.$tld";
  # Other parameters used in your _getConfigArray() function would also be available for use in this function

  try {
    $client = _olacv_Client();

    # Grab domain info
    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
    <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
        <command>
            <info>
                <domain:info xmlns:domain="urn:ietf:params:xml:ns:domain-1.0">
                    <domain:name hosts="all">' . $sld . '.' . $tld . '</domain:name>
                </domain:info>
            </info>
            <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
        </command>
    </epp>
';
    $request = $client->request($xml);

    $doc = new EppParser($request);
    logModuleCall('olacv', 'TransferSync', $xml, $request, null, []);

    $resultNode = $doc->getElementsByTagName('result')->item(0);
    if (!$resultNode) {
      return [
        'failed' => true,
        'error' => "TransferSync/domain-info($domain): No result in EPP response",
      ];
    }

    $msg = $doc->getMsg();

    # Check result
    if ($doc->doesNotExist()) {
      return [
        'failed' => true,
        'error' => "TransferSync/domain-info($domain): Domain not found",
      ];
    }
    if (!$doc->isSuccess()) {
      return [
        'failed' => true,
        'error' => "TransferSync/domain-info($domain): Code({$doc->getCode()}) $msg",
      ];
    }

    # Check if we can get a status back
    $statusNode = $doc->getElementsByTagName('status')->item(0);
    if (!$statusNode) {
      return [
        'failed' => true,
        'error' => "TransferSync/domain-info($domain): No status in EPP response",
      ];
    }

    $statusres = $statusNode->getAttribute('s');

    $exDateNode = $doc->getElementsByTagName('exDate')->item(0);
    $expiryDate = (new DateTime($exDateNode->nodeValue))->format('Y-m-d');

//        $crDateNode = $doc->getElementsByTagName('crDate')->item(0);
//        $createdDate = substr($doc->getElementsByTagName('crDate')->item(0)->nodeValue, 0, 10);
//        $expiryDate = substr($doc->getElementsByTagName('exDate')->item(0)->nodeValue, 0, 10);
//        $createdDate = $crDateNode ? (new DateTime($crDateNode->nodeValue))->format('Y-m-d') : null;

    $values['status'] = $msg;

    # Check status and update
    switch ($statusres) {
      case 'ok':
        $values['completed'] = true;
        break;
      case 'pendingTransfer':
        $values['pendingtransfer'] = true;
        break;
      default:
        $values['failed'] = true;
        $values['reason'] = "TransferSync/domain-info($domain): Unknown status '$statusres'";
    }

    $values['expirydate'] = $expiryDate;
  } catch (Exception $e) {
    $values['failed'] = true;
    $values['reason'] = 'TransferSync/EPP: ' . $e->getMessage();
  }

  return $values;
}

// we can use olacv_Sync script instead of using this function
function olacv_Sync($params)
{
  $sld = $params["sld"];
  $tld = $params["tld"];
  $domain = "$sld.$tld";

  try {
    $isActive = true;
    $isExpired = false;
    $isTransferredAway = false;
    $expiredDomain = false;

    # Query domain
    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
            <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
                <command>
                    <info>
                        <domain:info xmlns:domain="urn:ietf:params:xml:ns:domain-1.0">
                            <domain:name>' . $domain . '</domain:name>
                        </domain:info>
                    </info>
                    <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
                </command>
            </epp>';

    $client = _olacv_Client();
    $request = $client->request($xml);
    logModuleCall('olacv', 'Sync', $xml, $request, null, []);

    $doc = new EppParser($request);

    $coderes = $doc->getCode();
    $resultpr = $doc->getElementsByTagName('result')->item(0)->nodeValue;
    $msg = $doc->getMsg();

    $secondStatus = '';

    if (!$doc->isSuccess()) {
//            $values["error"] = "Sync/domain-info('.$domain.'): Code (" . $coderes . ") " . $msg;
//            $errorMsg = $values["error"];

      return [
        'error' => $msg
      ];
    }

    if ($coderes == 1000) {
      $statusNodes = $doc->getElementsByTagName('status');

      if ($statusNodes->length > 0) {
        if ($node = $statusNodes->item(0)) {
          $mainStatus = $node->getAttribute('s');
          $expiryDate = substr($doc->dom->getElementsByTagName('exDate')->item(0)->nodeValue, 0, 10);
          if ((time() - (60 * 60 * 24)) > strtotime($expiryDate)) {
            $expiredDomain = true;
          }
        } else {
          $values["error"] = "Sync/domain-info('.$domain.'): Code (" . $coderes . ") " . $msg;

          return [
            'error' => "Domain $domain not registered!"
          ];
        }

        if ($doc->dom->getElementsByTagName('status')->item(1)) {
          $secondStatus = $doc->getElementsByTagName('status')->item(1)->getAttribute('s');
        }
      }
    } else {
      $pendingStatus = 'Pending';

      if ($resultpr == 'Object does not exist') {
        $values["error"] = "Sync/domain-info('.$domain.'): Code (" . $resultpr . ") " . $msg;

        return [
          'error' => 'Object does not exist'
        ];
      } elseif ($resultpr == 'Authorization error') {
        $isTransferredAway = true;
        return [
          'transferredAway' => true,
          'error' => 'Authorization error.'
        ];
      }
    }

    # This is the template we going to use below for our updates
    # Check status and update
    if ($mainStatus == "ok") {
      $isActive = true;
    } elseif ($expiredDomain == false && $mainStatus == STATUS_INACTIVE && $secondStatus == STATUS_SERVER_HOLD) {
      $isActive = false;
    } elseif ($expiredDomain == false && $mainStatus == STATUS_INACTIVE && $secondStatus != STATUS_SERVER_HOLD) {
      $isActive = true;
    } elseif ($expiredDomain == false && $mainStatus == STATUS_SERVER_HOLD && $mainStatus != STATUS_INACTIVE) {
      $isActive = false;
    } elseif ($mainStatus == STATUS_PENDING_CREATE) {
      $isActive = false;
    } elseif ($mainStatus == STATUS_PENDING_DELETE) {
      $isExpired = true;
    } elseif ($mainStatus == STATUS_EXPIRED || $expiredDomain == true) {
      $isExpired = true;
    } else {
      $isExpired = false;
    }

    return [
      'expirydate' => $expiryDate, // Format: YYYY-MM-DD
      'active' => $isActive, // Return true if the domain is active
      'expired' => $isExpired, // Return true if the domain has expired
      'transferredAway' => $isTransferredAway, // Return true if the domain is transferred out
    ];
  } catch (Exception $e) {
    return [
      'error' => $e->getMessage(),
    ];
  }
}

function olacv_ApproveTransfer($params)
{
  $sld = $params['sld'];
  $tld = $params['tld'];

  $domain = "$sld.$tld";
  #
  try {
    $client = _olacv_Client();

    # Approve Transfer Request
    $request = $client->request(
      $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
   <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
	<command>
		<transfer op="approve">
			<domain:transfer xmlns:domain="urn:ietf:params:xml:ns:domain-1.0">
				<domain:name>' . $domain . '</domain:name>
			</domain:transfer>
		</transfer>
		<clTRID>' . mt_rand() . mt_rand() . '</clTRID>
	</command>
</epp>
'
    );

    # Parse XML result
    $doc = new EppParser($request);
    logModuleCall('olacv', 'ApproveTransfer', $xml, $request);

    $coderes = $doc->getCode();
    $msg = $doc->getElementsByTagName('msg')->item(0)->nodeValue;

    # Check result
    if (!$doc->isSuccess()) {
      $values['error'] = 'ApproveTransfer/domain-info(' . $domain . '): Code(' . _olacv_message(
          $coderes
        ) . ") $msg";
      return $values;
    }

    $values['status'] = $msg;
  } catch (Exception $e) {
    $values["error"] = 'ApproveTransfer/EPP: ' . $e->getMessage();
    return $values;
  }

  return $values;
}

function olacv_CancelTransferRequest($params)
{
  $sld = $params['sld'];
  $tld = $params['tld'];
  $domain = "$sld.$tld";
  try {
    $client = _olacv_Client();

    # Cancel Transfer Request
    $request = $client->request(
      $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
   <epp xmlns="urn:ietf:params:xml:ns:epp1.0">
	<command>
		<transfer op="cancel">
			<domain:transfer xmlns:domain="urn:ietf:params:xml:ns:domain1.0">
				<domain:name>' . $sld . '.' . $tld . '</domain:name>
			</domain:transfer>
		</transfer>
		<clTRID>' . mt_rand() . mt_rand() . '</clTRID>
	</command>
</epp>
'
    );
    logModuleCall('olacv', 'CancelTransferRequest', $xml, $request, null, []);

    # Parse XML result
    $doc = new EppParser($request);

    $coderes = $doc->getCode();
    $msg = $doc->getElementsByTagName('msg')->item(0)->nodeValue;

    # Check result
    if (!$doc->isSuccess()) {
      $values['error'] = 'CancelTransferRequest/domain-info(' . $sld . '.' . $tld . '): Code(' . _olacv_message(
          $coderes
        ) . ") $msg";
      return $values;
    }

    $values['status'] = $msg;
  } catch (Exception $e) {
    $values["error"] = 'CancelTransferRequest/EPP: ' . $e->getMessage();
    return $values;
  }

  return $values;
}

function olacv_RejectTransfer($params)
{
  $sld = $params['sld'];
  $tld = $params['tld'];
  $domain = "$sld.$tld";
  try {
    $client = _olacv_Client();

    # Reject Transfer
    $request = $client->request(
      $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
   <epp xmlns="urn:ietf:params:xml:ns:epp1.0">
	<command>
		<transfer op="reject">
			<domain:transfer xmlns:domain="urn:ietf:params:xml:ns:domain1.0">
				<domain:name>' . $domain . '</domain:name>
			</domain:transfer>
		</transfer>
		<clTRID>' . mt_rand() . mt_rand() . '</clTRID>
	</command>
</epp>
'
    );

    # Parse XML result
    $doc = new EppParser($request);

    logModuleCall('olacv', 'RejectTransfer', $xml, $request, null, []);
    _olacv_logout($client);

    $coderes = $doc->getCode();
    $msg = $doc->getElementsByTagName('msg')->item(0)->nodeValue;

    # Check result
    if (!$doc->isSuccess()) {
      $values['error'] = 'RejectTransfer/domain-info(' . $domain . '): Code(' . _olacv_message(
          $coderes
        ) . ") $msg";
      return $values;
    }

    $values['status'] = $msg;
  } catch (Exception $e) {
    $values["error"] = 'RejectTransfer/EPP: ' . $e->getMessage();
    return $values;
  }

  return $values;
}

//DNSSEC
function olacv_manageDNSSECRecords($params)
{
  $sld = $params['sld'];
  $tld = $params['tld'];

  $domain = "$sld.$tld";

  try {
    $client = _olacv_Client();

    if (isset($_POST['command']) && ($_POST['command'] === 'secDNSadd')) {
      $keyTag = $_POST['keyTag'];
      $alg = $_POST['alg'];
      $digestType = $_POST['digestType'];
      $digest = $_POST['digest'];

      $request = $client->request(
        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<epp xmlns="urn:ietf:params:xml:ns:epp-1.0"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="urn:ietf:params:xml:ns:epp-1.0 epp-1.0.xsd">
  <command>
	<update>
	  <domain:update xmlns:domain="urn:ietf:params:xml:ns:domain-1.0"
	   xsi:schemaLocation="urn:ietf:params:xml:ns:domain-1.0 domain-1.0.xsd">
		<domain:name>' . $domain . '</domain:name>
	  </domain:update>
	</update>
    <extension>
      <secDNS:update xmlns:secDNS="urn:ietf:params:xml:ns:secDNS-1.1">
        <secDNS:add>
          <secDNS:dsData>
            <secDNS:keyTag>' . $keyTag . '</secDNS:keyTag>
            <secDNS:alg>' . $alg . '</secDNS:alg>
            <secDNS:digestType>' . $digestType . '</secDNS:digestType>
            <secDNS:digest>' . $digest . '</secDNS:digest>
          </secDNS:dsData>
        </secDNS:add>
      </secDNS:update>
    </extension>	
	<clTRID>' . mt_rand() . mt_rand() . '</clTRID>
  </command>
</epp>'
      );
      logModuleCall('olacv', 'DNSSECADDDSRecord', $xml, $request, null, []);

      $doc = new EppParser($request);
      $resultpr = $doc->getElementsByTagName('result')->item(0)->nodeValue;

      if (!$doc->isSuccess()) {
        throw new Exception($resultpr);
      }
    }
    if (isset($_POST['command']) && ($_POST['command'] === 'secDNSrem')) {
      $keyTag = $_POST['keyTag'];
      $alg = $_POST['alg'];
      $digestType = $_POST['digestType'];
      $digest = $_POST['digest'];


      $request = $client->request(
        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<epp xmlns="urn:ietf:params:xml:ns:epp-1.0"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="urn:ietf:params:xml:ns:epp-1.0 epp-1.0.xsd">
  <command>
	<update>
	  <domain:update
	   xmlns:domain="urn:ietf:params:xml:ns:domain-1.0"
	   xsi:schemaLocation="urn:ietf:params:xml:ns:domain-1.0 domain-1.0.xsd">
		<domain:name>' . $domain . '</domain:name>
	  </domain:update>
	</update>
    <extension>
      <secDNS:update xmlns:secDNS="urn:ietf:params:xml:ns:secDNS-1.1">
        <secDNS:rem>
          <secDNS:dsData>
            <secDNS:keyTag>' . $keyTag . '</secDNS:keyTag>
            <secDNS:alg>' . $alg . '</secDNS:alg>
            <secDNS:digestType>' . $digestType . '</secDNS:digestType>
            <secDNS:digest>' . $digest . '</secDNS:digest>
          </secDNS:dsData>
        </secDNS:rem>
      </secDNS:update>
    </extension>	
	<clTRID>' . mt_rand() . mt_rand() . '</clTRID>
  </command>
</epp>'
      );
      logModuleCall('olacv', 'DNSSECREMDSRecord', $xml, $request, null, []);

      $doc = new EppParser($request);
    }

    $request = $client->request(
      $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<epp xmlns="urn:ietf:params:xml:ns:epp-1.0"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="urn:ietf:params:xml:ns:epp-1.0 epp-1.0.xsd">
  <command>
	<info>
	  <domain:info
	   xmlns:domain="urn:ietf:params:xml:ns:domain-1.0"
	   xsi:schemaLocation="urn:ietf:params:xml:ns:domain-1.0 domain-1.0.xsd">
		<domain:name hosts="all">' . $domain . '</domain:name>
	  </domain:info>
	</info>
	<clTRID>' . mt_rand() . mt_rand() . '</clTRID>
  </command>
</epp>'
    );
    logModuleCall('olacv', 'DNSSECINFODSRecord', $xml, $request, null, []);

    $doc = new EppParser($request);
    $secDNSdsData = [];

    // Check if extension and infData elements exist
    $extensionElements = $doc->dom->getElementsByTagNameNS('urn:ietf:params:xml:ns:epp-1.0', 'extension');

    if ($extensionElements->length > 0) {
      $infDataElements = $extensionElements->item(0)->getElementsByTagNameNS('urn:ietf:params:xml:ns:secDNS-1.1', 'infData');

      if ($infDataElements->length > 0) {
        $DSRecords = 'YES';
        $i = 0;

        // Iterate over dsData elements
        $dsDataElements = $infDataElements->item(0)->getElementsByTagNameNS(
          'urn:ietf:params:xml:ns:secDNS-1.1',
          'dsData'
        );
        foreach ($dsDataElements as $dsData) {
          $i++;

          // Populate $secDNSdsData array
          $secDNSdsData[$i]["domainid"] = (int)$params['domainid'];
          $secDNSdsData[$i]["keyTag"] = (string)$dsData->getElementsByTagName('keyTag')->item(0)->nodeValue;
          $secDNSdsData[$i]["alg"] = (int)$dsData->getElementsByTagName('alg')->item(0)->nodeValue;
          $secDNSdsData[$i]["digestType"] = (int)$dsData->getElementsByTagName('digestType')->item(
            0
          )->nodeValue;
          $secDNSdsData[$i]["digest"] = (string)$dsData->getElementsByTagName('digest')->item(0)->nodeValue;
        }
      }
    } else {
      $DSRecords = "NO DS records for this domain";
    }

    $return = [
      'templatefile' => 'manageDNSSEC',
      'requirelogin' => true,
      'vars' => [
        'DSRecords' => $DSRecords,
        'DSRecordslist' => $secDNSdsData
      ]
    ];
  } catch (exception $e) {
    $return = [
      'templatefile' => 'manageDNSSEC',
      'requirelogin' => true,
      'vars' => [
        'error' => $e->getMessage()
      ]
    ];
  }

  return $return;
}

# Function to return a meaningful message from response code
function _olacv_message($code)
{
  return "Code $code";
}

# Function to create internal EPP request
function _olacv_Client()
{
  # Grab module parameters
  $params = getregistrarconfigoptions('olacv');

  # Check if module parameters are sane
  if (empty($params['Username']) || empty($params['Password'])) {
    throw new Exception('System configuration error(1), please contact your provider');
  }

  $host = $params['Server'];
  $port = $params['Port'];

  $context = stream_context_create([
    'ssl' => [
      'verify_peer' => false,
      'verify_peer_name' => false
    ]
  ]);

  # Are we using ssl?
  $use_ssl = true;
  if (!empty($params['SSL']) && $params['SSL'] == 'on') {
    $use_ssl = true;
  }
  # Set a certificate if we have one
  if ($use_ssl && !empty($params['Certificate'])) {
    if (!file_exists($params['Certificate'])) {
      throw new Exception("System configuration , please contact your provider");
    }
    # Set a client side certificate
    stream_context_set_option($context, 'ssl', 'local_cert', $params['Certificate']);
  }

  # Create EPP client
  $client = new Client();
  $client->connect($host, $port, 60, $use_ssl, $context);

  _olacv_login($client, $params);
  return $client;
}

function _olacv_login(Client $client, $params)
{
  $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
  <command>
    <login>
      <clID>' . $params['Username'] . '</clID>
      <pw>' . $params['Password'] . '</pw>
      <options>
        <version>1.0</version>
        <lang>en</lang>
      </options>
      <svcs>
        <objURI>urn:ietf:params:xml:ns:obj1</objURI>
        <objURI>urn:ietf:params:xml:ns:obj2</objURI>
        <objURI>urn:ietf:params:xml:ns:obj3</objURI>
        <svcExtension>
          <extURI>http://custom/obj1ext-1.0</extURI>
          <extURI>urn:ietf:params:xml:ns:epp:fee-1.0</extURI>
        </svcExtension>
      </svcs>
    </login>
    <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
  </command>
</epp>';
  $request = $client->request($xml);

  logModuleCall('olacv', 'login', $xml, $request, null, [$params['Password'], $params['Username']]);
}


function _olacv_logout(Client $client)
{
  $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<epp xmlns="urn:ietf:params:xml:ns:epp-1.0" xmlns:sidn-ext-epp="http://rxsd.domain-registry.nl/sidn-ext-epp-1.0">
  <command>
    <logout></logout>
    <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
  </command>
</epp>';

  try {
    $response = $client->request($xml);
    logModuleCall('olacv', 'logout', $xml, $response, null, []);
  } catch (Exception $e) {
  }

  $client->disconnect();
}

function _olacv_generateHandle(): string
{
  $stamp = time();
  $shuffled = str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
  $randStr = substr($shuffled, mt_rand(0, 45), 5);
  return "$stamp$randStr";
}

function _olacv_array_empty($array): bool
{
  foreach ($array as $item) {
    if (!empty($item)) {
      return false;
    }
  }

  return true;
}

function _olacv_authKey(): string
{
  $chars = 'a0Zb1Yc2Xd3We4Vf5Ug6Th7Si8Rj9Qk8Pl7Om6Nn5Mo4Lp3Kq2Jr1Is0Ht1Gu2Fv3Ew4Dx5Cy6Bz7A';
  $len = strlen($chars) - 1;
  $key = '';

  for ($i = 0; $i < 10; $i++) {
    $key .= $chars[mt_rand(0, $len)];
  }

  return $key;
}

# Determine IP version IPV4:IPV6
function _olacv_detectIpVersion($ip): string
{
  if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
    return 'IPv4';
  } elseif (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
    return 'IPv6';
  }

  return 'Error: Invalid IP';
}

function _olacv_generateAuthCode($domain)
{
  $key = _olacv_getOrCreateInstallKey();

  $hash = hash_hmac('sha256', $domain, $key);
  return substr($hash, 0, 14);
}

function _olacv_getOrCreateInstallKey(): string
{
  return '';


  $settingName = 'EppSalt';
  $registrar = 'olacv';

  $existing = Capsule::table('tblregistrars')
    ->where('registrar', $registrar)
    ->where('setting', $settingName)
    ->first();

  if ($existing && !empty($existing->value)) {
    return $existing->value;
  }

  $key = strtoupper(bin2hex(random_bytes(16))); // 32-char key
  Capsule::table('tblregistrars')->insert([
    'registrar' => $registrar,
    'setting' => $settingName,
    'value' => $key,
  ]);

  return $key;
}

/**
 * @param $client
 * @param $contactID
 * @return array
 * @throws Exception
 */
function _olacv_getContactDetail($client, $contactID)
{
  $request = $client->request(
    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
    <command>
        <info>
            <contact:info xmlns:contact="urn:ietf:params:xml:ns:contact-1.0">
                <contact:id>' . $contactID . '</contact:id>
            </contact:info>
        </info>
    <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
    </command>
</epp>'
  );

  # Parse XML result
  $doc = new EppParser($request);
  logModuleCall('olacv', 'GetContactDetails', $xml, $request, null, []);

  $msg = $doc->getMsg();

  # Check results
  if (!$doc->isSuccess()) {
    throw new Exception("contact-info($contactID): Code (" . $doc->getCode() . ") " . $doc->getMsg());
  }

  $contact["Contact Name"] = $doc->getSingleElementValue('name');
  $contact["Company Name"] = $doc->getSingleElementValue('org');
  $contact["Address 1"] = $doc->getSingleElementValue('street');
  $contact["Address 2"] = $doc->getSingleElementValue('street', 1);
  $contact["City"] = $doc->getSingleElementValue('city');
  $contact["State"] = $doc->getSingleElementValue('sp');
  $contact["ZIP code"] = $doc->getSingleElementValue('pc');
  $contact["Country"] = $doc->getSingleElementValue('cc');
  $contact["Phone"] = $doc->getSingleElementValue('voice');
  $contact["Email"] = $doc->getSingleElementValue('email');

  return $contact;
}

function _olacv_changeContact($client, $newdata, $handle, $type = "")
{
  $xml = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
  <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
    <command>
      <update>
        <contact:update xmlns:contact="urn:ietf:params:xml:ns:contact-1.0">
          <contact:id>' . $handle . '</contact:id>
          <contact:chg>
            <contact:postalInfo type="int">
              <contact:name>' . $newdata["Contact Name"] . ' </contact:name>
              <contact:org>' . $newdata["Company Name"] . '</contact:org>
              <contact:addr>
                <contact:street>' . $newdata["Address 1"] . '</contact:street>
                <contact:street>' . $newdata["Address 2"] . '</contact:street>
                <contact:city>' . $newdata["City"] . '</contact:city>
                <contact:sp>' . $newdata["State"] . '</contact:sp>
                <contact:pc>' . $newdata["ZIP code"] . '</contact:pc>
                <contact:cc>' . $newdata["Country"] . '</contact:cc>
              </contact:addr>
            </contact:postalInfo>
            <contact:voice>' . $newdata["Phone"] . '</contact:voice>
            <contact:email>' . $newdata["Email"] . '</contact:email>
          </contact:chg>
        </contact:update>
      </update>
      <clTRID>' . mt_rand() . mt_rand() . '</clTRID>
	</command>
  </epp>';

  $result = $client->request($xml);
  logModuleCall('olacv', 'SaveContactDetails', $xml, $result, null, []);

  # Parse XML result
  $doc = new EppParser($result);
  if (!$doc->isSuccess()) {
    throw new Exception("contact-create($handle) $type: Code ({$doc->getCode()}()) {$doc->getMsg()}");
  }

  return $handle;
}


function _olacv_parseDomainCheckResponse(string $xml, $enablePremium = false)
{
  $dom = new EppParser($xml);

  $dom->xpath->registerNamespace('epp', 'urn:ietf:params:xml:ns:epp-1.0');
  $dom->xpath->registerNamespace('domain', 'urn:ietf:params:xml:ns:domain-1.0');
  $dom->xpath->registerNamespace('fee', 'urn:ietf:params:xml:ns:epp:fee-1.0');

  $list = new ResultsList();
  $results = [];
  foreach ($dom->xpath->query('//domain:cd') as $cd) {
    $nameNode = $dom->xpath->query('domain:name', $cd)->item(0);

    if (!$nameNode) {
      continue;
    }

    $domain = trim($nameNode->nodeValue);
    $isAvailable = $nameNode->getAttribute('avail') === '1';
    $results[$domain] = [
      'available' => $isAvailable,
      'currency' => null,
      'status' => $isAvailable ? 'not_registered' : 'registered',
      'is_premium' => false
    ];
  }

  $currencyNode = $dom->xpath->query('//fee:currency')->item(0);
  $currency = $currencyNode ? trim($currencyNode->nodeValue) : null;

  foreach ($dom->xpath->query('//fee:cd') as $cd) {
    $domainNode = $dom->xpath->query('fee:objID', $cd)->item(0);

    if (!$domainNode) {
      continue;
    }

    $domain = trim($domainNode->nodeValue);
    if (!isset($results[$domain])) {
      continue;
    }

    $classNode = $dom->xpath->query('fee:class', $cd)->item(0);
    if ($classNode) {
      $results[$domain]['is_premium'] = trim($classNode->nodeValue) == 'premium';
    }

    $results[$domain]['currency'] = $currency;
    foreach ($dom->xpath->query('fee:command', $cd) as $commandNode) {
      $operation = $commandNode->getAttribute('name');
      switch ($operation) {
        case 'create':
          $feeType = 'registration_fee';
          break;
        case 'renew':
          $feeType = 'renewal_fee';
          break;
        case 'transfer':
          $feeType = 'transfer_fee';
          break;
        case 'restore':
          $feeType = 'restore_fee';
          break;
        default:
          $feeType = $operation;
      }

      $total = 0.0;
      foreach ($dom->xpath->query('fee:fee', $commandNode) as $feeNode) {
        $total += (float)trim($feeNode->nodeValue);
      }

      $results[$domain][$feeType] = $total;
    }
  }

  foreach ($results as $domain => $details) {
    $parts = explode('.', strtolower(trim($domain)));
    $count = count($parts);

    if ($count >= 3) {
      $tld = $parts[$count - 2] . '.' . $parts[$count - 1];
    } else {
      $tld = $parts[$count - 1];
    }

    //Split
    $searchResult = new SearchResult($parts[0], $tld);
    switch ($details['status']) {
      case "not_registered":
        $status = SearchResult::STATUS_NOT_REGISTERED;
        break;
      case "registered":
        $status = SearchResult::STATUS_REGISTERED;
        break;
      case "reserved":
        $status = SearchResult::STATUS_RESERVED;
        break;
      case "not_supported":
      case "unknown":
      default:
        $status = SearchResult::STATUS_TLD_NOT_SUPPORTED;
        break;
    }
    if (!$enablePremium && $details['is_premium']) {
      $status = SearchResult::STATUS_RESERVED;
    }
    $searchResult->setStatus($status);

    if ($details['is_premium']) {
      $price = [
        'register' => $details['registration_fee'],
        'renew' => $details['renewal_fee'],
        'transfer' => $details['transfer_fee'],
        'CurrencyCode' => $details['currency'],
      ];

      $searchResult->setPremiumDomain(true);
      $searchResult->setPremiumCostPricing($price);
    }

    $list->append($searchResult);
  }

  return $list;
}

function _olacv_generateSuggestions(string $word, int $limit = 10, $tlds = ['cv', 'com.cv', 'org.cv', 'edu.cv']): array
{
  $word = trim($word);

  if (!$word) {
    return [];
  }

  $prefixes = [
    'be',
    'bit',
    'flow',
    'get',
    'go',
    'my',
    'neo',
    'pro',
    'pure',
    'quick',
    'smart',
    'the',
    'top',
    'real',
    'true',
    'try',
    'use',
    'we',
    'zen',
  ];
  $suffixes = [
    'ai',
    'app',
    'bit',
    'bot',
    'core',
    'flow',
    'hq',
    'hub',
    'ify',
    'io',
    'lab',
    'ly',
    'now',
    'official',
    'offline',
    'one',
    'online',
    'peak',
    'portfolio',
    'pro',
    'up',
    'wave',
    'zen',
    date('Y'),
  ];

  $suggestions = [];
  $used = [];

  // Helper: add unique domain
  $add = function ($domain) use (&$suggestions, &$used, $limit) {
    $domain = strtolower($domain);
    if (!in_array($domain, $used) && count($suggestions) < $limit * 3) {
      $suggestions[] = $domain;
      $used[] = $domain;
    }
  };

  // 1. Clean: word.tld
  foreach ($tlds as $tld) {
    $add("{$word}.{$tld}");
  }

  // 2. Prefix + Word
  foreach ($prefixes as $p) {
    $combo = "{$p}{$word}";
    foreach ($tlds as $tld) {
      $add("{$combo}.{$tld}");
    }
  }

  // 3. Word + Suffix
  foreach ($suffixes as $suffix) {
    $combo = "{$word}{$suffix}";
    $tld = ($suffix === 'io' || $suffix === 'ai') ? 'cv' : (in_array($suffix, ['app', 'lab', 'hub']
    ) ? 'com.cv' : 'cv');
    $add("{$combo}.{$tld}");
  }

  // 4. Blended: word + synonym/related
  $synonyms = [
    'shop' => ['mart', 'store', 'cart', 'buy', 'sell'],
    'food' => ['eat', 'bite', 'meal', 'dish', 'chef'],
    'chat' => ['talk', 'msg', 'say', 'voice'],
    'learn' => ['study', 'edu', 'skill', 'grow'],
    'work' => ['job', 'task', 'do', 'pro'],
  ];

  $related = $synonyms[$word] ?? [];
  foreach ($related as $rel) {
    $add("{$word}{$rel}.cv");
    $add("{$rel}{$word}.com.cv");

    foreach (['hub', 'lab', 'pro'] as $suffix) {
      $add("{$word}{$rel}{$suffix}.cv");
    }
  }

  // 5. AI Patterns: verb + noun, noun + verb
  $verbs = ['get', 'try', 'make', 'build', 'grow', 'find', 'join'];
  $nouns = [$word, 'it', 'now', 'easy', 'fast', 'pro'];

  foreach ($verbs as $verb) {
    foreach ($nouns as $noun) {
      if ($noun !== 'it') {
        $add("{$verb}{$noun}.cv");
      }
    }
  }

  // 6. Modern brandable: short + suffix
  $short = strlen($word) > 5 ? substr($word, 0, 4) : $word;
  foreach (['ly', 'io', 'ai', 'up', 'go'] as $suffix) {
    $add("{$short}{$suffix}.cv");
  }

  // Final: shuffle & limit
  shuffle($suggestions);
  return array_slice(array_unique($suggestions), 0, $limit);
}

class EppParser
{
  public $dom;
  public $xpath;

  private $namespaces = [
    'epp' => 'urn:ietf:params:xml:ns:epp-1.0',
    'domain' => 'urn:ietf:params:xml:ns:domain-1.0',
    'contact' => 'urn:ietf:params:xml:ns:contact-1.0',
    'host' => 'urn:ietf:params:xml:ns:host-1.0',
    'rgp' => 'urn:ietf:params:xml:ns:rgp-1.0',
    'secDNS' => 'urn:ietf:params:xml:ns:secDNS-1.1',
    'fee' => 'urn:ietf:params:xml:ns:fee-0.7' // Common for pricing
  ];

  public function __construct(string $xml = null)
  {
    $this->dom = new DOMDocument();
    $this->dom->preserveWhiteSpace = false;

    if (!empty($xml)) {
      $this->loadXML($xml);
    }
  }

  public function loadXML($xml)
  {
    if (!@$this->dom->loadXML($xml)) {
      throw new Exception("Failed to load XML.");
    }

    $this->xpath = new DOMXPath($this->dom);
    foreach ($this->namespaces as $prefix => $uri) {
      $this->xpath->registerNamespace($prefix, $uri);
    }
  }

  /**
   * Check if the command was successful
   */
  public function isSuccess(): bool
  {
    $code = (int)$this->queryValue('//epp:result/@code');
    return ($code >= 1000 && $code < 2000);
  }

  public function getResultInfo(): array
  {
    return [
      'code' => $this->getCode(),
      'msg' => $this->getMsg(),
      'svTRID' => $this->queryValue('//epp:trID/e:svTRID')
    ];
  }

  public function getCode()
  {
    return (int)$this->queryValue('//epp:result/@code');
  }

  public function getMsg()
  {
    return $this->queryValue('//epp:result/e:msg') ?? 'No message provided';
  }

  /**
   * Extract key extensions like DNSSEC or RGP
   */
  public function getExtensions(): array
  {
    $ext = [];

    // 1. Check for DNSSEC (secDNS)
    $dsData = $this->xpath->query('//secDNS:dsData');
    if ($dsData->length > 0) {
      foreach ($dsData as $node) {
        $ext['dnssec'][] = [
          'keyTag' => $this->queryValue('.//secDNS:keyTag', $node),
          'alg' => $this->queryValue('.//secDNS:alg', $node),
          'digestType' => $this->queryValue('.//secDNS:digestType', $node),
          'digest' => $this->queryValue('.//secDNS:digest', $node),
        ];
      }
    }

    // 2. Check for RGP (Redemption)
    $rgpStatus = $this->queryValue('//rgp:rgpStatus/@s');
    if ($rgpStatus) {
      $ext['rgp_status'] = $rgpStatus;
    }

    return $ext;
  }

  /**
   * Primary Domain Data Extraction
   */
  public function getDomainData(): array
  {
    $statuses = $this->queryValues('//domain:status/@s');

    $transferLock = (
      in_array('serverTransferProhibited', $statuses) ||
      in_array('clientTransferProhibited', $statuses)
    );

    $nameservers = $this->queryValues('//domain:ns/domain:hostObj');
    $ns = [];
    $index = 1;
    foreach ($nameservers as $nameserver) {
      $ns["ns{$index}"] = $nameserver;
      $index++;
    }

    return [
      'domain' => $this->queryValue('//domain:name'),
      'status' => $statuses,
      'registrant' => $this->queryValue('//domain:registrant'),
      'contacts' => [
        'admin' => $this->queryValue('//domain:contact[@type=\'admin\']'),
        'billing' => $this->queryValue('//domain:contact[@type=\'billing\']'),
        'tech' => $this->queryValue('//domain:contact[@type=\'tech\']'),
      ],
      'dates' => [
        'created' => $this->queryValue('//domain:crDate'),
        'expiry' => $this->queryValue('//domain:exDate'),
        'updated' => $this->queryValue('//domain:upDate'),
      ],
      'registrar' => $this->queryValue('//domain:clID'),
      'nameservers' => $ns,
      'transferlock' => $transferLock,
      'restorable' => true,
    ];
  }

  /**
   * Specifically extracts Contact Info from a <contact:infData> response
   */
  public function getContactData(): array
  {
    // Find the root contact info node
    $base = '//contact:infData';

    if ($this->xpath->query($base)->length === 0) {
      return [];
    }

    return [
      'id' => $this->queryValue("$base/contact:id"),
      'roid' => $this->queryValue("$base/contact:roid"),
      'status' => $this->queryValues("$base/contact:status/@s"),
      'email' => $this->queryValue("$base/contact:email"),
      'phone' => $this->queryValue("$base/contact:voice"),
      'fax' => $this->queryValue("$base/contact:fax"),
      'postal' => $this->getPostalInfo($base),
      'dates' => [
        'created' => $this->queryValue("$base/contact:crDate"),
        'updated' => $this->queryValue("$base/contact:upDate"),
      ],
      'clID' => $this->queryValue("$base/contact:clID"),
    ];
  }

  /**
   * Helper to parse the nested <contact:postalInfo> block
   */
  private function getPostalInfo(string $base): array
  {
    $postal = [];
    // Usually 'int' or 'loc'
    $nodes = $this->xpath->query("$base/contact:postalInfo");

    foreach ($nodes as $node) {
      $type = $node->getAttribute('type');

      $postal[$type] = [
        'name' => $this->queryValue("contact:name", $node),
        'org' => $this->queryValue("contact:org", $node),
        'addr' => [
          'street' => $this->queryValues("contact:addr/contact:street", $node),
          'city' => $this->queryValue("contact:addr/contact:city", $node),
          'sp' => $this->queryValue("contact:addr/contact:sp", $node), // State/Province
          'pc' => $this->queryValue("contact:addr/contact:pc", $node), // Postal Code
          'cc' => $this->queryValue("contact:addr/contact:cc", $node), // Country Code
        ]
      ];
    }
    return $postal;
  }

  // --- Helper Methods ---
  public function queryValue(string $path, $context = null): ?string
  {
    $nodes = $this->xpath->query($path, $context);
    return ($nodes && $nodes->length > 0) ? $nodes->item(0)->nodeValue : null;
  }

  private function queryValues(string $path): array
  {
    $nodes = $this->xpath->query($path);
    $results = [];
    foreach ($nodes as $node) {
      $results[] = $node->nodeValue;
    }
    return $results;
  }

  public function existsAlready(): bool
  {
    return $this->getCode() === 2302;
  }

  public function doesNotExist(): bool
  {
    return $this->getCode() === 2303;
  }

  public function getDomainStatus(): string
  {
    $status = $this->queryValue('//domain:status/@s');
    return $status ? $status : 'unknown';
  }

  public function getElementsByTagName($name): DOMNodeList
  {
    return $this->dom->getElementsByTagName($name);
  }

  public function getSingleElementValue(
    string $tag,
    int $index = 0,
    ?string $default = null
  ): ?string {
    $nodes = $this->getElementsByTagName($tag);

    if ($nodes->length <= $index) {
      return $default;
    }

    $value = trim($nodes->item($index)->nodeValue);

    return $value !== '' ? $value : $default;
  }

}

